<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Consulta <?php echo e($consulta->id); ?></title>
    <style>
        body { font-family: sans-serif; font-size: 13px; }
        h2 { margin-bottom: 0; }
        .seccion { margin: 18px 0; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 6px; border: 1px solid #ccc; }
        .titulo { font-size: 18px; margin-bottom: 10px; font-weight: bold; }
    </style>
</head>
<body>

    <h2>Consulta #<?php echo e($consulta->id); ?></h2>
    <p>Fecha: <?php echo e($consulta->fecha_consulta?->format('d/m/Y H:i')); ?></p>
    <hr>

    <div class="seccion">
        <div class="titulo">Datos del Paciente</div>
        <p><strong>Nombre:</strong> <?php echo e($consulta->paciente->nombre); ?></p>
        <p><strong>Identidad:</strong> <?php echo e($consulta->paciente->identidad); ?></p>
        <p><strong>Edad:</strong> <?php echo e($consulta->paciente->edad); ?> años</p>
    </div>

    <div class="seccion">
        <div class="titulo">Motivo de Consulta</div>
        <p><?php echo nl2br(e($consulta->motivo)); ?></p>
    </div>

    <div class="seccion">
        <div class="titulo">Diagnóstico</div>
        <p><?php echo nl2br(e($consulta->diagnostico)); ?></p>
        <?php if($consulta->cie10): ?>
            <p><strong>CIE10:</strong> <?php echo e($consulta->cie10); ?></p>
        <?php endif; ?>
    </div>

    <div class="seccion">
        <div class="titulo">Signos Vitales</div>
        <table>
            <tr><th>Peso</th><td><?php echo e($consulta->peso); ?></td></tr>
            <tr><th>Estatura</th><td><?php echo e($consulta->estatura); ?></td></tr>
            <tr><th>Presión Arterial</th><td><?php echo e($consulta->presion_arterial); ?></td></tr>
            <tr><th>FC</th><td><?php echo e($consulta->frecuencia_cardiaca); ?></td></tr>
            <tr><th>FR</th><td><?php echo e($consulta->frecuencia_respiratoria); ?></td></tr>
            <tr><th>Temperatura</th><td><?php echo e($consulta->temperatura); ?></td></tr>
            <tr><th>Saturación O₂</th><td><?php echo e($consulta->saturacion_o2); ?></td></tr>
        </table>
    </div>

    <div class="seccion">
        <div class="titulo">Tratamiento</div>
        <p><?php echo nl2br(e($consulta->tratamiento)); ?></p>
    </div>

    <div class="seccion">
        <div class="titulo">Exámenes Solicitados</div>
        <?php if($consulta->examenes): ?>
            <ul>
                <?php $__currentLoopData = $consulta->examenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($ex); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p>No se solicitaron exámenes.</p>
        <?php endif; ?>
    </div>

    <div class="seccion">
        <div class="titulo">Incapacidad</div>
        <?php if($consulta->dias_incapacidad): ?>
            <p><strong>Días:</strong> <?php echo e($consulta->dias_incapacidad); ?></p>
            <p><strong>Inicio:</strong> <?php echo e($consulta->incapacidad_inicio); ?></p>
            <p><strong>Fin:</strong> <?php echo e($consulta->incapacidad_fin); ?></p>
        <?php else: ?>
            <p>No hubo incapacidad.</p>
        <?php endif; ?>
    </div>

    <div class="seccion">
        <div class="titulo">Remisión</div>
        <?php if($consulta->hospital_destino): ?>
            <p><strong>Centro:</strong> <?php echo e($consulta->hospital_destino); ?></p>
            <p><strong>Motivo:</strong> <?php echo nl2br(e($consulta->motivo_remision)); ?></p>
        <?php else: ?>
            <p>No hubo remisión.</p>
        <?php endif; ?>
    </div>

    <div class="seccion">
        <div class="titulo">Archivos Adjuntos</div>
        <?php if($consulta->archivos->count()): ?>
            <ul>
                <?php $__currentLoopData = $consulta->archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($archivo->nombre_archivo); ?>

                        (<?php echo e($archivo->created_at->format('d/m/Y H:i')); ?>)
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p>No hay archivos adjuntos.</p>
        <?php endif; ?>
    </div>

</body>
</html>
<?php /**PATH C:\wamp64\www\clinica-medica\resources\views/pdf/consulta-completa.blade.php ENDPATH**/ ?>