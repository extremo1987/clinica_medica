

<?php $__env->startSection('content'); ?>


<style>
/* ======== ESTILO GENERAL TABS ========= */
.nav-tabs .nav-link {
    border: none !important;
    color: #4a4a4a;
    font-weight: 600;
    padding: 10px 18px;
    border-radius: 10px 10px 0 0;
    transition: 0.25s;
}
.nav-tabs .nav-link:not(.active) {
    background: #f3f3f3;
}
.nav-tabs .nav-link:hover {
    filter: brightness(1.05);
}

/* ======== COLORES POR TAB ACTIVA ========= */
.nav-link[href="#motivo"].active { background:#caff9c!important; color:#125c0b!important; border-bottom:3px solid #72d44a; }
.nav-link[href="#signos"].active { background:#bde3ff!important; color:#0b3e66!important; border-bottom:3px solid #4ca3ff; }
.nav-link[href="#diagnostico"].active { background:#fff3a8!important; color:#665600!important; border-bottom:3px solid #e6d000; }
.nav-link[href="#tratamiento"].active { background:#ffd1df!important; color:#7a0030!important; border-bottom:3px solid #ff4f87; }
.nav-link[href="#receta"].active { background:#ffe2c4!important; color:#7a3900!important; border-bottom:3px solid #ff8f1f; }
.nav-link[href="#incapacidad"].active { background:#e8d1ff!important; color:#4a007a!important; border-bottom:3px solid #b566ff; }
.nav-link[href="#remision"].active { background:#d4fff7!important; color:#00635c!important; border-bottom:3px solid #22c7b8; }
.nav-link[href="#examenes"].active { background:#ccffe8!important; color:#006644!important; border-bottom:3px solid #2ecc71; }
.nav-link[href="#pago"].active { background:#ffe8a8!important; color:#6d4e00!important; border-bottom:3px solid #f2b600; }
.nav-link[href="#archivos"].active { background:#e6e6e6!important; color:#333!important; border-bottom:3px solid #999; }

/* Borde dinámico */
.tab-content {
    border: 3px solid #caff9c;
    border-radius: 0 12px 12px 12px;
    transition: border-color .25s ease-in-out;
}
</style>



<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css">
<script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify"></script>



<div class="page-body">
<div class="container-xl">

<h2 class="page-title mb-4">
    Nueva Consulta — <?php echo e($paciente->nombre); ?> 
    <span class="text-muted">(Expediente: <?php echo e($paciente->expediente); ?>)</span>
</h2>

    <div class="card shadow-lg" style="border-radius:18px;">
        <div class="card-body">

            <form action="<?php echo e(route('consultas.update', $consulta->id)); ?>"
                  method="POST"
                  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>


                
                <ul class="nav nav-tabs mb-3" id="consultaTabs">
                    <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#motivo">Motivo</a></li>
                    <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#signos">Signos Vitales</a></li>
                    <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#diagnostico">Diagnóstico</a></li>
                    <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tratamiento">Tratamiento</a></li>
                    <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#receta">Receta</a></li>
                    <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#incapacidad">Incapacidad</a></li>
                    <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#remision">Remisión</a></li>
                    <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#examenes">Exámenes</a></li>
                    <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#pago">Pago</a></li>
                    <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#archivos">Archivos Adjuntos</a></li>
                </ul>



                
                <div class="tab-content p-3 shadow-sm">


                    
                    <div class="tab-pane fade show active" id="motivo">
                        <label class="form-label">Motivo de consulta</label>
                        <textarea name="motivo" class="form-control" rows="3"><?php echo e($consulta->motivo); ?></textarea>
                    </div>


                    
                    <div class="tab-pane fade" id="signos">

                        <h5 class="mb-3">Signos Vitales</h5>

                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label>Peso</label>
                                <input type="text" name="peso" class="form-control" value="<?php echo e($consulta->peso); ?>">
                            </div>

                            <div class="col-md-3 mb-3">
                                <label>Estatura</label>
                                <input type="text" name="estatura" class="form-control" value="<?php echo e($consulta->estatura); ?>">
                            </div>

                            <div class="col-md-3 mb-3">
                                <label>Presión</label>
                                <input type="text" name="presion_arterial" class="form-control" value="<?php echo e($consulta->presion_arterial); ?>">
                            </div>

                            <div class="col-md-3 mb-3">
                                <label>Temperatura</label>
                                <input type="text" name="temperatura" class="form-control" value="<?php echo e($consulta->temperatura); ?>">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label>FC</label>
                                <input type="text" name="frecuencia_cardiaca" class="form-control" value="<?php echo e($consulta->frecuencia_cardiaca); ?>">
                            </div>

                            <div class="col-md-4 mb-3">
                                <label>FR</label>
                                <input type="text" name="frecuencia_respiratoria" class="form-control" value="<?php echo e($consulta->frecuencia_respiratoria); ?>">
                            </div>

                            <div class="col-md-4 mb-3">
                                <label>Saturación O₂</label>
                                <input type="text" name="saturacion_o2" class="form-control" value="<?php echo e($consulta->saturacion_o2); ?>">
                            </div>
                        </div>
                    </div>


                    
                    <div class="tab-pane fade" id="diagnostico">
                        <label class="form-label">Diagnóstico</label>
                        <textarea name="diagnostico" class="form-control" rows="3"><?php echo e($consulta->diagnostico); ?></textarea>

                        <label class="form-label mt-3">Código CIE10</label>
                        <input type="text" name="cie10" class="form-control" value="<?php echo e($consulta->cie10); ?>">
                    </div>


                    
                    <div class="tab-pane fade" id="tratamiento">
                        <label class="form-label">Tratamiento</label>
                        <textarea name="tratamiento" class="form-control" rows="4"><?php echo e($consulta->tratamiento); ?></textarea>
                    </div>


                    
                    <div class="tab-pane fade" id="receta">
                        <label class="form-label">Receta Médica</label>
                        <textarea name="receta" class="form-control" rows="6"><?php echo e($consulta->receta); ?></textarea>
                    </div>


                    
                    <div class="tab-pane fade" id="incapacidad">

                        <h5 class="mb-3">Incapacidad Médica</h5>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label>Días</label>
                                <input type="number" name="dias_incapacidad" class="form-control"
                                       value="<?php echo e($consulta->dias_incapacidad); ?>">
                            </div>

                            <div class="col-md-4 mb-3">
                                <label>Desde</label>
                                <input type="date" name="incapacidad_inicio" class="form-control"
                                       value="<?php echo e($consulta->incapacidad_inicio); ?>">
                            </div>

                            <div class="col-md-4 mb-3">
                                <label>Hasta</label>
                                <input type="date" name="incapacidad_fin" class="form-control"
                                       value="<?php echo e($consulta->incapacidad_fin); ?>">
                            </div>
                        </div>
                    </div>


                    
                    <div class="tab-pane fade" id="remision">

                        <h5 class="mb-3">Remisión</h5>

                        <label>Centro Médico</label>
                        <input type="text" name="hospital_destino" class="form-control mb-3"
                               value="<?php echo e($consulta->hospital_destino); ?>">

                        <label>Motivo</label>
                        <textarea name="motivo_remision" class="form-control" rows="3"><?php echo e($consulta->motivo_remision); ?></textarea>
                    </div>


                    
                    <div class="tab-pane fade" id="examenes">
                        <h5 class="mb-3">Exámenes Solicitados</h5>

                        <input id="inputExamenes"
                               name="examenes"
                               class="form-control"
                               value="<?php echo e($consulta->examenes ? implode(',', $consulta->examenes) : ''); ?>">
                    </div>


                    
                    <div class="tab-pane fade" id="pago">
                        <h5 class="mb-3">Pago</h5>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label>Monto</label>
                                <input type="number" step="0.01" name="monto" class="form-control"
                                       value="<?php echo e($consulta->monto); ?>">
                            </div>

                            <div class="col-md-4 mb-3">
                                <label>Tipo de Pago</label>
                                <select name="tipo_pago" class="form-select">
                                    <option <?php echo e($consulta->tipo_pago=='Efectivo'?'selected':''); ?>>Efectivo</option>
                                    <option <?php echo e($consulta->tipo_pago=='Tarjeta'?'selected':''); ?>>Tarjeta</option>
                                    <option <?php echo e($consulta->tipo_pago=='Transferencia'?'selected':''); ?>>Transferencia</option>
                                    <option <?php echo e($consulta->tipo_pago=='Sin Cobro'?'selected':''); ?>>Sin Cobro</option>
                                </select>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label>Estado</label>
                                <select name="pagado" class="form-select">
                                    <option value="0" <?php echo e(!$consulta->pagado ? 'selected':''); ?>>Pendiente</option>
                                    <option value="1" <?php echo e($consulta->pagado ? 'selected':''); ?>>Pagado</option>
                                </select>
                            </div>
                        </div>
                    </div>


                    
                    <div class="tab-pane fade" id="archivos">

                        <h5 class="mb-3">Archivos existentes</h5>

                        <?php $__currentLoopData = $consulta->archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="border rounded p-2 mb-2">

                                <p class="mb-1">
                                    📄 <strong><?php echo e($archivo->nombre_archivo); ?></strong>
                                </p>

                                <a href="<?php echo e(asset('storage/'.$archivo->ruta_archivo)); ?>" target="_blank"
                                   class="btn btn-primary btn-sm">Ver / Descargar</a>

                                <a href="<?php echo e(route('consultas.archivo.delete', $archivo->id)); ?>"
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('¿Eliminar archivo?')">
                                    Eliminar
                                </a>

                                <p class="text-muted mt-1"><?php echo e($archivo->observacion); ?></p>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <hr>

                        <h5 class="mb-3">Agregar Nuevos Archivos</h5>

                        <div id="contenedor-archivos">
                            <div class="row mb-3 archivo-item">
                                <div class="col-md-6">
                                    <input type="file" name="archivos[]" class="form-control">
                                </div>

                                <div class="col-md-6">
                                    <input type="text" name="observaciones_archivo[]" class="form-control"
                                           placeholder="Descripción del archivo">
                                </div>
                            </div>
                        </div>

                        <button type="button" id="btnAgregarArchivo" class="btn btn-secondary mt-2">
                            + Agregar otro archivo
                        </button>

                    </div>

                </div>


                
                <div class="mt-4 text-end">
                    <a href="<?php echo e(route('consultas.show', $consulta->id)); ?>" class="btn btn-secondary">Cancelar</a>
                    <button class="btn btn-primary">Actualizar Consulta</button>
                </div>

            </form>

        </div>
    </div>

</div>
</div>



<script>
document.getElementById("btnAgregarArchivo").addEventListener("click", function() {
    let cont = document.getElementById("contenedor-archivos");

    let html = `
    <div class="row mb-3 archivo-item">
        <div class="col-md-6">
            <input type="file" name="archivos[]" class="form-control">
        </div>
        <div class="col-md-6">
            <input type="text" name="observaciones_archivo[]" class="form-control"
                   placeholder="Descripción del archivo">
        </div>
    </div>`;

    cont.insertAdjacentHTML("beforeend", html);
});
</script>



<script>
document.addEventListener("DOMContentLoaded", function() {

    let activeTab = localStorage.getItem("consulta_tab_edit");

    if (activeTab) {
        let trigger = document.querySelector(`a[href="${activeTab}"]`);
        if (trigger) new bootstrap.Tab(trigger).show();
    }

    const contentBox = document.querySelector('.tab-content');

    const colores = {
        "#motivo": "#caff9c",
        "#signos": "#bde3ff",
        "#diagnostico": "#fff3a8",
        "#tratamiento": "#ffd1df",
        "#receta": "#ffe2c4",
        "#incapacidad": "#e8d1ff",
        "#remision": "#d4fff7",
        "#examenes": "#ccffe8",
        "#pago": "#ffe8a8",
        "#archivos": "#e6e6e6",
    };

    document.querySelectorAll('#consultaTabs a').forEach(tab => {
        tab.addEventListener("shown.bs.tab", function(e) {
            let id = e.target.getAttribute("href");
            if (colores[id]) contentBox.style.borderColor = colores[id];
            localStorage.setItem("consulta_tab_edit", id);
        });
    });
});
</script>




<script>
document.addEventListener("DOMContentLoaded", function () {

    fetch("<?php echo e(route('examenes.list')); ?>")
        .then(res => res.json())
        .then(lista => {

            let input = document.getElementById("inputExamenes");

            let tagify = new Tagify(input, {
                whitelist: lista,
                dropdown: {
                    enabled: 1,
                    maxItems: 15,
                    searchKeys: ["value"]
                },
                enforceWhitelist: true, // permite crear nuevos
            });
        });
});
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\clinica-medica\resources\views/consultas/edit.blade.php ENDPATH**/ ?>