<?php $__env->startSection('content'); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>

<style>
    .role-badge {
        padding: 6px 10px;
        border-radius: 14px;
        font-size: 13px;
        font-weight: 600;
        color: #fff !important;
    }
</style>

<div class="page-body">
    <div class="container-xl">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="page-title">Usuarios del Sistema</h2>

            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">
                <svg class="icon me-1" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                     viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                     fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z"/>
                    <path d="M12 5v14m-7 -7h14" />
                </svg>
                Nuevo Usuario
            </a>
        </div>

        <div class="card shadow-lg" style="border-radius:16px;">
            <div class="card-body">

                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-vcenter">
                        <thead class="table-light">
                            <tr>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Rol</th>
                                <th class="text-end">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>

                                    <td>
                                        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php
                                                $color = 'secondary'; // default

                                                if ($role->name === 'admin')         $color = 'danger';
                                                if ($role->name === 'doctor')        $color = 'success';
                                                if ($role->name === 'recepcion')     $color = 'primary';
                                                if ($role->name === 'enfermeria')    $color = 'info';
                                                if ($role->name === 'laboratorio')   $color = 'indigo';
                                            ?>

                                            <span class="role-badge bg-<?php echo e($color); ?>">
                                                <?php echo e($role->label); ?>

                                            </span>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>

                                    <td class="text-end">

                                        <a href="<?php echo e(route('users.edit', $user->id)); ?>"
                                           class="btn btn-sm btn-outline-primary">
                                            Editar
                                        </a>

                                        <button type="button"
                                                class="btn btn-sm btn-outline-danger"
                                                onclick="confirmDelete('<?php echo e(route('users.destroy', $user->id)); ?>')">
                                            Eliminar
                                        </button>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>



<div class="modal modal-blur fade" id="confirmDeleteModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Confirmar Eliminación</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body text-center">

        <svg xmlns="http://www.w3.org/2000/svg" class="icon mb-3 text-danger"
             width="48" height="48" stroke-width="2" stroke="currentColor" fill="none">
            <path d="M12 9v4m0 4v.01" />
            <path d="M5 19h14l-7 -14z" />
        </svg>

        <p class="text-muted">
            ¿Deseas eliminar este usuario?
            <br><strong>Esta acción no se puede deshacer.</strong>
        </p>

      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>

        <form id="deleteUserForm" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger">Eliminar</button>
        </form>
      </div>

    </div>
  </div>
</div>


<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener("DOMContentLoaded", function () {

    window.confirmDelete = function(actionUrl) {
        const modal = new bootstrap.Modal(document.getElementById("confirmDeleteModal"));
        document.getElementById("deleteUserForm").action = actionUrl;
        modal.show();
    };

});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\clinica-medica\resources\views/users/index.blade.php ENDPATH**/ ?>