

<?php $__env->startSection('content'); ?>

<div class="page-body">
    <div class="container-xl">

        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="page-title">Ficha Clínica del Paciente</h2>
            <a href="<?php echo e(route('pacientes.index')); ?>" class="btn btn-secondary">Volver</a>
        </div>

        
        <div class="card shadow-lg" style="border-radius: 18px;">
            <div class="card-body">

                
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h3 class="fw-bold mb-1"><?php echo e($paciente->nombre); ?></h3>

                        <span class="badge bg-primary" style="font-size:14px; color:#fff; font-weight:bold;">
    Expediente: <?php echo e($paciente->expediente); ?>

</span>

                    </div>

                    
                    <a href="<?php echo e(route('consultas.create', $paciente->id)); ?>" class="btn btn-success">
                        Nueva Consulta
                    </a>
                </div>

                
                <div class="patient-info-section p-3 mb-4">
                    <h4 class="fw-bold mb-3 text-primary">🧍 Información del Paciente</h4>

                    <div class="row g-3">

                        <div class="col-md-6">
                            <div class="info-box">
                                <label>Identidad</label>
                                <p><?php echo e($paciente->identidad ?: '—'); ?></p>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="info-box">
                                <label>Edad</label>
                                <p><?php echo e($paciente->edad ? $paciente->edad.' años' : '—'); ?></p>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="info-box">
                                <label>Fecha Nacimiento</label>
                                <p><?php echo e($paciente->fecha_nacimiento ?: '—'); ?></p>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="info-box">
                                <label>Teléfono</label>
                                <p><?php echo e($paciente->telefono ?: '—'); ?></p>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="info-box">
                                <label>Email</label>
                                <p><?php echo e($paciente->email ?: '—'); ?></p>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="info-box">
                                <label>Sexo</label>
                                <p>
                                    <?php if($paciente->sexo === 'M'): ?> Masculino
                                    <?php elseif($paciente->sexo === 'F'): ?> Femenino
                                    <?php else: ?> — <?php endif; ?>
                                </p>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="info-box">
                                <label>Dirección</label>
                                <p><?php echo e($paciente->direccion ?: '—'); ?></p>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>

        
        <div class="card shadow-sm mt-4" style="border-radius: 16px;">
            <div class="card-body">
                <h3 class="mb-3">Historial de Consultas</h3>

                <?php
                    $consultas = $paciente->consultas ?? collect();
                ?>

                <?php if($consultas->isEmpty()): ?>

                    <div class="alert alert-info text-center">
                        Este paciente aún no tiene consultas registradas.
                    </div>

                <?php else: ?>

                    <div class="table-responsive">
                        <table id="consultasTable" class="table table-striped table-bordered">
                            <thead class="table-primary">
                                <tr>
                                    <th>Fecha</th>
                                    <th>Motivo</th>
                                    <th>Diagnóstico</th>
                                    <th class="text-end">Acciones</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($c->fecha_consulta?->format('d/m/Y') ?: '—'); ?></td>
                                        <td><?php echo e($c->motivo ?: '—'); ?></td>
                                        <td><?php echo e($c->diagnostico ?: '—'); ?></td>

                                        <td class="text-end">

                                            
                                            <a href="<?php echo e(route('consultas.show', $c->id)); ?>" class="btn btn-sm btn-info">
                                                Ver
                                            </a>

                                            
                                            <a href="<?php echo e(route('consultas.edit', $c->id)); ?>" class="btn btn-sm btn-primary">
                                                Editar
                                            </a>

                                            
                                            <?php if(!empty($c->receta)): ?>
                                            <form method="POST"
                                                  action="<?php echo e(route('consultas.receta.pdf', $c->paciente_id)); ?>"
                                                  class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="consulta_id" value="<?php echo e($c->id); ?>">
                                                <button class="btn btn-sm btn-success">
                                                    Receta PDF
                                                </button>
                                            </form>
                                            <?php endif; ?>

                                            
                                            <?php if(!empty($c->dias_incapacidad) && $c->incapacidad_inicio && $c->incapacidad_fin): ?>
                                            <form method="POST"
                                                  action="<?php echo e(route('consultas.incapacidad.pdf', $c->paciente_id)); ?>"
                                                  class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="consulta_id" value="<?php echo e($c->id); ?>">
                                                <button class="btn btn-sm btn-warning">
                                                    Incapacidad PDF
                                                </button>
                                            </form>
                                            <?php endif; ?>

                                            
                                            <?php if(!empty($c->hospital_destino) && !empty($c->motivo_remision)): ?>
                                            <form method="POST"
                                                  action="<?php echo e(route('consultas.remision.pdf', $c->paciente_id)); ?>"
                                                  class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="consulta_id" value="<?php echo e($c->id); ?>">
                                                <button class="btn btn-sm btn-danger">
                                                    Remisión PDF
                                                </button>
                                            </form>
                                            <?php endif; ?>

                                            
                                            <form action="<?php echo e(route('consultas.destroy', $c->id)); ?>"
                                                  method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <button onclick="return confirm('¿Eliminar consulta?')"
                                                        class="btn btn-sm btn-outline-danger">
                                                    Eliminar
                                                </button>
                                            </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>

                <?php endif; ?>

            </div>
        </div>

    </div>
</div>


<style>
.patient-info-section {
    background: #f8faff;
    border: 1px solid #dbe2f0;
    border-radius: 14px;
}
.info-box {
    background: white;
    border: 1px solid #d9e2ef;
    padding: 12px 15px;
    border-radius: 12px;
}
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\clinica-medica\resources\views/pacientes/show.blade.php ENDPATH**/ ?>