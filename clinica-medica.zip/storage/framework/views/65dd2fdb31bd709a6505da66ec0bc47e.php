<div id="sidebar" aria-hidden="false">
    <h3 class="fw-bold mb-4">Clínica Médica</h3>
    
    
    <a href="<?php echo e(url('/dashboard')); ?>"
       class="sidebar-link <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
        Dashboard
    </a>

    
    <a href="<?php echo e(route('pacientes.index')); ?>"
       class="sidebar-link <?php echo e(request()->is('pacientes*') ? 'active' : ''); ?>">
        Pacientes
    </a>

    
    <a href="#" class="sidebar-link">
        Exámenes
    </a>

    
    <a href="#" class="sidebar-link">
        Reportes
    </a>

    
    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
        <a href="<?php echo e(route('settings.index')); ?>"
           class="sidebar-link <?php echo e(request()->is('configuracion') ? 'active' : ''); ?>">
            Configuración
        </a>
    <?php endif; ?>

    
    
    
    <?php if(auth()->check() && (
        auth()->user()->hasRole('admin') ||
        auth()->user()->hasPermission('users.view') ||
        auth()->user()->hasPermission('users.manage')
    )): ?>

        
        <a href="<?php echo e(route('users.index')); ?>"
           class="sidebar-link <?php echo e(request()->is('users*') ? 'active' : ''); ?>">
            Usuarios
        </a>

        
        <?php if(auth()->user()->hasRole('admin') ||
            auth()->user()->hasPermission('roles.view') ||
            auth()->user()->hasPermission('roles.manage')): ?>
            
            <a href="<?php echo e(route('roles.index')); ?>"
               class="sidebar-link sub-link <?php echo e(request()->is('roles*') ? 'active' : ''); ?>"
               style="margin-left:18px;">
                • Roles
            </a>
        <?php endif; ?>

        
        <?php if(auth()->user()->hasRole('admin') ||
            auth()->user()->hasPermission('permissions.view') ||
            auth()->user()->hasPermission('permissions.manage')): ?>

            <a href="<?php echo e(route('permissions.index')); ?>"
               class="sidebar-link sub-link <?php echo e(request()->is('permissions*') ? 'active' : ''); ?>"
               style="margin-left:18px;">
                • Permisos
            </a>
        <?php endif; ?>

    <?php endif; ?>

</div>
<?php /**PATH C:\wamp64\www\clinica-medica\resources\views/components/sidebar.blade.php ENDPATH**/ ?>