

<?php $__env->startSection('content'); ?>
<div class="page-body">
<div class="container-xl">

    <h2 class="page-title mb-4">Editar Paciente</h2>

    <div class="card shadow-lg" style="border-radius: 16px;">
        <div class="card-body">

            <form action="<?php echo e(route('pacientes.update', $paciente->id)); ?>"
                  method="POST"
                  enctype="multipart/form-data">

                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row">

                    
                    <div class="col-md-4 mb-4 text-center">

                        <h5 class="mb-2">Foto del Paciente</h5>

                        
                        <img id="previewFoto"
                             src="<?php echo e($paciente->foto ? asset('storage/'.$paciente->foto) : asset('images/default-user.png')); ?>"
                             class="rounded border mb-3"
                             style="width:180px;height:180px;object-fit:cover;">

                        
                        <input type="file"
                               name="foto"
                               id="fotoInput"
                               class="form-control mb-3"
                               accept="image/*">

                        <hr>

                        
                        <h6>Tomar Foto con Cámara</h6>

                        <video id="camera"
                               autoplay
                               playsinline
                               class="border rounded mb-2"
                               style="width:180px;height:180px;object-fit:cover;"></video>

                        <button type="button"
                                id="btnTomarFoto"
                                class="btn btn-sm btn-primary w-100 mb-2">
                            📷 Tomar Foto
                        </button>

                        <input type="hidden" name="foto_capturada" id="foto_capturada">
                        <canvas id="canvas" style="display:none;"></canvas>

                    </div>

                    
                    <div class="col-md-8">

                        <div class="row">

                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Nombre Completo *</label>
                                <input type="text"
                                       name="nombre"
                                       value="<?php echo e($paciente->nombre); ?>"
                                       class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       required>
                                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Identidad</label>
                                <input type="text"
                                       name="identidad"
                                       value="<?php echo e($paciente->identidad); ?>"
                                       class="form-control">
                            </div>

                        </div>

                        <div class="row">

                            
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Teléfono</label>
                                <input type="text"
                                       name="telefono"
                                       value="<?php echo e($paciente->telefono); ?>"
                                       class="form-control">
                            </div>

                            
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Correo Electrónico</label>
                                <input type="email"
                                       name="email"
                                       value="<?php echo e($paciente->email); ?>"
                                       class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Sexo</label>
                                <select name="sexo" class="form-select">
                                    <option value="">-- Seleccione --</option>
                                    <option value="M" <?php if($paciente->sexo=="M"): echo 'selected'; endif; ?>>Masculino</option>
                                    <option value="F" <?php if($paciente->sexo=="F"): echo 'selected'; endif; ?>>Femenino</option>
                                </select>
                            </div>

                        </div>

                        <div class="row">

                            
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Fecha de Nacimiento</label>
                                <input type="date"
                                       name="fecha_nacimiento"
                                       id="fecha_nacimiento"
                                       value="<?php echo e($paciente->fecha_nacimiento); ?>"
                                       class="form-control">
                            </div>

                            
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Edad</label>
                                <input type="text"
                                       id="edad"
                                       name="edad"
                                       value="<?php echo e($paciente->edad); ?>"
                                       class="form-control"
                                       readonly>
                            </div>

                            
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Dirección</label>
                                <input type="text"
                                       name="direccion"
                                       value="<?php echo e($paciente->direccion); ?>"
                                       class="form-control">
                            </div>

                        </div>

                    </div>
                </div>

                
                <div class="mt-3 text-end">
                    <a href="<?php echo e(route('pacientes.show', $paciente->id)); ?>" class="btn btn-secondary">Cancelar</a>
                    <button class="btn btn-primary">Actualizar Paciente</button>
                </div>

            </form>

        </div>
    </div>

</div>
</div>



<script>
function calcularEdad() {
    let fecha = document.getElementById('fecha_nacimiento').value;
    if (!fecha) return;

    let nacimiento = new Date(fecha);
    let hoy = new Date();

    let edad = hoy.getFullYear() - nacimiento.getFullYear();
    let mes = hoy.getMonth() - nacimiento.getMonth();

    if (mes < 0 || (mes === 0 && hoy.getDate() < nacimiento.getDate())) {
        edad--;
    }

    document.getElementById('edad').value = edad;
}

document.getElementById('fecha_nacimiento').addEventListener('change', calcularEdad);
<?php if($paciente->fecha_nacimiento): ?> calcularEdad(); <?php endif; ?>
</script>



<script>
let video = document.getElementById("camera");
let canvas = document.getElementById("canvas");
let preview = document.getElementById("previewFoto");

// Activar cámara
navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => video.srcObject = stream)
    .catch(err => console.log("No se pudo acceder a la cámara:", err));

// Tomar foto
document.getElementById("btnTomarFoto").addEventListener("click", function() {

    // Dibujar en canvas
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext("2d").drawImage(video, 0, 0);

    // Convertir a Base64
    let dataURL = canvas.toDataURL("image/png");

    // Poner en input y preview
    document.getElementById("foto_capturada").value = dataURL;
    preview.src = dataURL;
});

// Vista previa al subir archivo
document.getElementById("fotoInput").addEventListener("change", function() {
    if (this.files && this.files[0]) {
        preview.src = URL.createObjectURL(this.files[0]);
    }
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\clinica-medica\resources\views/pacientes/edit.blade.php ENDPATH**/ ?>