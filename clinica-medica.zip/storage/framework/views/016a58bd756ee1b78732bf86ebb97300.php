

<?php $__env->startSection('content'); ?>

<style>
@media print {

    /* Ocultar botones y elementos no imprimibles */
    .no-print, .navbar, .btn, a.btn {
        display: none !important;
    }

    /* Reset del body para impresión */
    body, html {
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        background: white !important;
    }

    /* Contenedor a todo lo ancho (página carta o A4) */
    .container-xl, .page-body, .card {
        width: 100% !important;  
        max-width: 100% !important;
        margin: 0 !important;
        padding: 20px !important; /* agrega márgenes internos para que no quede tan pegado */
        box-shadow: none !important;
        border: none !important;
    }

    /* Quitar bordes y estilos gráficos si deseas */
    .card {
        border: none !important;
    }

    /* Ajustar tablas para que usen todo el ancho */
    table {
        width: 100% !important;
    }
}
</style>



<div class="page-body">
<div class="container-xl">

    
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="page-title">Consulta #<?php echo e($consulta->id); ?></h2>

        <a href="<?php echo e(route('pacientes.show', $consulta->paciente_id)); ?>" class="btn btn-secondary no-print">
            Volver a Ficha Clínica
        </a>
    </div>

    
    <div class="d-flex gap-2 mb-3 no-print">
        <a href="javascript:window.print();" class="btn btn-dark">
            🖨️ Imprimir
        </a>

        <a href="<?php echo e(route('consultas.pdf.completa', $consulta->id)); ?>" class="btn btn-primary">
            📄 Exportar PDF
        </a>
    </div>

    
    <div class="card shadow-lg" style="border-radius: 18px;">
        <div class="card-body">

            
            <h3 class="mb-3">Datos del Paciente</h3>

            <p><strong>Nombre:</strong> <?php echo e($consulta->paciente->nombre); ?></p>
            <p><strong>Identidad:</strong> <?php echo e($consulta->paciente->identidad); ?></p>
            <p><strong>Edad:</strong> <?php echo e($consulta->paciente->edad); ?> años</p>
            <hr>

            
            <h3 class="mb-3">Detalles de la Consulta</h3>

            <p><strong>Fecha:</strong> <?php echo e($consulta->fecha_consulta?->format('d/m/Y H:i')); ?></p>

            <p><strong>Motivo de Consulta:</strong><br>
                <?php echo nl2br(e($consulta->motivo)); ?>

            </p>

            <p><strong>Diagnóstico:</strong><br>
                <?php echo nl2br(e($consulta->diagnostico)); ?>

            </p>

            <?php if($consulta->cie10): ?>
                <p><strong>Código CIE10:</strong> <?php echo e($consulta->cie10); ?></p>
            <?php endif; ?>

            <hr>

            
            <h3 class="mb-3">Signos Vitales</h3>

            <table class="table table-bordered">
                <tr><th>Peso</th><td><?php echo e($consulta->peso); ?> kg</td></tr>
                <tr><th>Estatura</th><td><?php echo e($consulta->estatura); ?> cm</td></tr>
                <tr><th>Presión Arterial</th><td><?php echo e($consulta->presion_arterial); ?></td></tr>
                <tr><th>Frecuencia Cardiaca</th><td><?php echo e($consulta->frecuencia_cardiaca); ?> lpm</td></tr>
                <tr><th>Frecuencia Respiratoria</th><td><?php echo e($consulta->frecuencia_respiratoria); ?></td></tr>
                <tr><th>Temperatura</th><td><?php echo e($consulta->temperatura); ?> °C</td></tr>
                <tr><th>Saturación O₂</th><td><?php echo e($consulta->saturacion_o2); ?> %</td></tr>
            </table>

            <hr>

            
            <h3 class="mb-3">Tratamiento / Receta</h3>

            <p><?php echo nl2br(e($consulta->tratamiento)); ?></p>

            <hr>

            
            <h3 class="mb-3">Exámenes Solicitados</h3>

            <?php if($consulta->examenes): ?>
                <ul>
                <?php $__currentLoopData = $consulta->examenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($ex); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <p class="text-muted">No se solicitaron exámenes.</p>
            <?php endif; ?>

            <hr>

            
            <h3 class="mb-3">Incapacidad</h3>

            <?php if($consulta->dias_incapacidad): ?>
                <p><strong>Días:</strong> <?php echo e($consulta->dias_incapacidad); ?></p>
                <p><strong>Desde:</strong> <?php echo e($consulta->incapacidad_inicio); ?></p>
                <p><strong>Hasta:</strong> <?php echo e($consulta->incapacidad_fin); ?></p>
            <?php else: ?>
                <p class="text-muted">No se generó incapacidad.</p>
            <?php endif; ?>

            <hr>

            
            <h3 class="mb-3">Remisión</h3>

            <?php if($consulta->hospital_destino): ?>
                <p><strong>Centro Médico:</strong> <?php echo e($consulta->hospital_destino); ?></p>
                <p><strong>Motivo:</strong><br>
                    <?php echo nl2br(e($consulta->motivo_remision)); ?>

                </p>
            <?php else: ?>
                <p class="text-muted">No hubo remisión.</p>
            <?php endif; ?>

            <hr>

            
            <h3 class="mb-3">Archivos Adjuntos</h3>

            <?php if($consulta->archivos->count()): ?>
                <ul>
                    <?php $__currentLoopData = $consulta->archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mb-2">
                            📄 <strong><?php echo e(ucfirst($archivo->tipo_archivo)); ?></strong><br>

                            <a href="<?php echo e(asset('storage/'.$archivo->ruta_archivo)); ?>" 
                               class="btn btn-sm btn-primary mt-1 no-print"
                               target="_blank">
                                Descargar PDF
                            </a>

                            <small class="d-block text-muted mt-1">
                                <?php echo e($archivo->observacion ?: 'Sin observación'); ?>  
                                — <?php echo e($archivo->created_at->format('d/m/Y H:i')); ?>

                            </small>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <p class="text-muted">No hay archivos adjuntos.</p>
            <?php endif; ?>

        </div>
    </div>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\clinica-medica\resources\views/consultas/show.blade.php ENDPATH**/ ?>